﻿using Microsoft.EntityFrameworkCore;
using ProductModule.Models;

namespace ProductModule.Data
{
    public class ApplicationDbContext : DbContext

    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Product> Product_tbl { get; set; }

    }
}
