﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json;

namespace ProductModule.Models
{
    public class Product
    {
        [Key]
        public int ProductId { get; set; }
        [Required]
        public String? ProductName { get; set; }
        [Required]
        public int Quantity { get; set; }
        [Required]
        public double Price { get; set; }

        public string FilePath { get; set; } = "[]";  //store filepath as a json

        [NotMapped]//convert JSON to List<String>
        public List<IFormFile> FileUpload { get; set; } = new List<IFormFile> { };
        public List<String> FilePathList 
        {
            get => string.IsNullOrEmpty(FilePath) ? new List<string>() : JsonSerializer.Deserialize<List<string>>(FilePath);
            set => FilePath = JsonSerializer.Serialize(value) ; 
        }
    }
}
