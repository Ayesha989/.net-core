﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductModule.Data;
using ProductModule.Helpers;
using ProductModule.Models;

namespace ProductModule.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;
        public ProductController(ApplicationDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]

        public async Task<IActionResult> GetAllProduct()
        {
            var product_list = await _context.Product_tbl.ToListAsync();

            return Json(product_list);
        }

        [HttpPost]
        public async Task<IActionResult> CreateProduct([FromForm] Product product)
        {
            /*
            // ✅ 1. Check if all data is received correctly
            Console.WriteLine("Product Name: " + model.ProductName);
            Console.WriteLine("Quantity: " + model.Quantity);
            Console.WriteLine("Price: " + model.Price);

            // ✅ 2. Check uploaded files
            if (model.FileUpload != null && model.FileUpload.Count > 0)
            {
                foreach (var file in model.FileUpload)
                {
                    Console.WriteLine("File: " + file.FileName);
                }
            }
            else
            {
                Console.WriteLine("No files uploaded.");
            }
            // ✅ 3. Return a success response (for AJAX success callback)
            return Json(new { message = "Product data received successfully!", data = model });*/
            // return View();
            if (product == null || string.IsNullOrEmpty(product.ProductName) || product.FileUpload == null || product.FileUpload.Count == 0)
            {
                return BadRequest(new { message = "Please provide all required fields and at least one image." });
            }

            var imagePaths = new List<string>();
            var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");

            if (!Directory.Exists(uploadsFolder))
            {
                Directory.CreateDirectory(uploadsFolder);
            }
            foreach (var file in product.FileUpload)
            {
                var uniqueFileName = $"{Guid.NewGuid()}_{file.FileName}";
                var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }

                imagePaths.Add($"/uploads/{uniqueFileName}");
            }


            product.FilePathList = imagePaths; // Convert List<string> to JSON string

            // Save to database
            _context.Product_tbl.Add(product);
            await _context.SaveChangesAsync();

            return Json(new { message = "Product added successfully!", product });
        }

        [HttpPost]
        public IActionResult AddToCart(int productId)
        {
            // Retrieve the existing cart from session or create a new one
            List<int> cart = HttpContext.Session.GetObjectFromJson<List<int>>("Cart") ?? new List<int>();

            if (!cart.Contains(productId))
            {
                cart.Add(productId); // Add product to cart
                HttpContext.Session.SetObjectAsJson("Cart", cart);
            }

            return Json(new { message = "Product added to cart", cartCount = cart.Count });
        }

        public async Task<IActionResult> Cart( )
        {
            List<int> cartProductId = HttpContext.Session.GetObjectFromJson<List<int>>("Cart") ?? new List<int>();
            List<Product> cartProducts = await _context.Product_tbl
                .Where(p => cartProductId.Contains(p.ProductId)).ToListAsync();

            return View(cartProducts);
        }



        }
}
